let canvas;
let productId;
let productData;

// Utilisez la même liste de produits que dans categories-personnalisation-script.js
const products = [
  {
    id: 1,
    name: "T-shirt",
    price: 19.99,
    image: "images/Tshirt.jpg",
    template: "images/Tshirt.jpg",
  },
  {
    id: 2,
    name: "Pantalon",
    price: 39.99,
    image: "images/pantalon.jpg",
    template: "images/pantalon_template.png",
  },
  {
    id: 3,
    name: "Chaussures",
    price: 59.99,
    image: "images/chaussures.jpg",
    template: "images/chaussures_template.png",
  },
  {
    id: 4,
    name: "Casquette",
    price: 14.99,
    image: "images/casquette.jpg",
    template: "images/casquette_template.png",
  },
];

document.addEventListener("DOMContentLoaded", function () {
  canvas = new fabric.Canvas("productCanvas");

  // Récupérez l'ID du produit depuis l'URL
  const urlParams = new URLSearchParams(window.location.search);
  productId = urlParams.get("product");

  // Trouvez les données du produit correspondant
  productData = products.find((p) => p.id == productId);

  if (productData) {
    loadProductTemplate(productData.template);
    updatePrice();
    document.getElementById("productName").textContent = productData.name;
  } else {
    alert("Produit non trouvé");
  }

  initializeControls();
});

function loadProductTemplate(templatePath) {
  fabric.Image.fromURL(templatePath, function (img) {
    canvas.clear();
    canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas), {
      scaleX: canvas.width / img.width,
      scaleY: canvas.height / img.height,
    });
  });
}

function updatePrice() {
  let currentPrice = productData.price;
  // Ajoutez ici la logique pour ajuster le prix en fonction des personnalisations
  document.getElementById("price").textContent = currentPrice.toFixed(2);
}

function initializeControls() {
  // Ajoutez ici le code pour initialiser les contrôles de personnalisation
  // (comme dans le code précédent que je vous ai fourni)
}
