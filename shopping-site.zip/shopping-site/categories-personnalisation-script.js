const products = [
  {
    id: 1,
    name: "T-shirt",
    price: 19.99,
    image: "images/Tshirt.jpg",
    template: "images/Tshirt.jpg",
  },
  {
    id: 2,
    name: "Pantalon",
    price: 39.99,
    image: "images/pantalon.jpg",
    template: "images/pantalon_template.png",
  },
  {
    id: 3,
    name: "Chaussures",
    price: 59.99,
    image: "images/chaussures.jpg",
    template: "images/chaussures_template.png",
  },
  {
    id: 4,
    name: "Casquette",
    price: 14.99,
    image: "images/casquette.jpg",
    template: "images/casquette_template.png",
  },
];

function displayProducts() {
  const productGrid = document.getElementById("productGrid");
  productGrid.innerHTML = "";

  products.forEach((product) => {
    const productElement = document.createElement("div");
    productElement.classList.add("product-item");
    productElement.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.price.toFixed(2)} $</p>
        `;
    productElement.addEventListener("click", () => {
      // Rediriger vers la page de personnalisation avec l'ID du produit
      window.location.href = `personnalisation.html?product=${product.id}`;
    });
    productGrid.appendChild(productElement);
  });
}

document.addEventListener("DOMContentLoaded", displayProducts);
