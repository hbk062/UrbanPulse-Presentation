let cart = JSON.parse(localStorage.getItem("cart")) || [];

function updateCartDisplay() {
  const cartItems = document.getElementById("cart-items");
  cartItems.innerHTML = "";

  let subtotal = 0;

  cart.forEach((item) => {
    const itemTotal = item.price * item.quantity;
    subtotal += itemTotal;

    const itemElement = document.createElement("div");
    itemElement.classList.add("cart-item");
    itemElement.innerHTML = `
            <div class="cart-item-details">
                <span class="cart-item-name">${item.name}</span>
                <span class="cart-item-price">${item.price.toFixed(2)} $ x ${
      item.quantity
    }</span>
            </div>
            <button class="remove-item" onclick="removeFromCart(${
              item.id
            })">X</button>
        `;
    cartItems.appendChild(itemElement);
  });

  const tps = subtotal * 0.05;
  const tvq = subtotal * 0.09975;
  const total = subtotal + tps + tvq;

  document.getElementById("subtotal").textContent = subtotal.toFixed(2);
  document.getElementById("tps").textContent = tps.toFixed(2);
  document.getElementById("tvq").textContent = tvq.toFixed(2);
  document.getElementById("total").textContent = total.toFixed(2);
}

function removeFromCart(productId) {
  cart = cart.filter((item) => item.id !== productId);
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartDisplay();
}

document.addEventListener("DOMContentLoaded", () => {
  updateCartDisplay();
});

document.getElementById("checkout-btn").addEventListener("click", () => {
  alert("Merci pour votre commande !");
  localStorage.removeItem("cart");
  cart = [];
  updateCartDisplay();
});

document.addEventListener("DOMContentLoaded", () => {
  const paymentOptions = document.querySelectorAll('input[name="payment"]');
  const creditCardForm = document.getElementById("credit-card-form");
  const checkoutBtn = document.getElementById("checkout-btn");
  const ccForm = document.getElementById("cc-form");

  paymentOptions.forEach((option) => {
    option.addEventListener("change", (e) => {
      if (e.target.value === "credit-card") {
        creditCardForm.style.display = "block";
      } else {
        creditCardForm.style.display = "none";
      }
    });
  });

  checkoutBtn.addEventListener("click", () => {
    const selectedPayment = document.querySelector(
      'input[name="payment"]:checked'
    );
    if (!selectedPayment) {
      alert("Veuillez sélectionner une méthode de paiement.");
      return;
    }

    switch (selectedPayment.value) {
      case "paypal":
        // Rediriger vers PayPal
        alert("Redirection vers PayPal...");
        break;
      case "credit-card":
        // Le formulaire de carte de crédit est déjà visible
        break;
      case "apple-pay":
        // Intégrer Apple Pay
        alert("Paiement avec Apple Pay...");
        break;
      case "google-pay":
        // Intégrer Google Pay
        alert("Paiement avec Google Pay...");
        break;
    }
  });

  ccForm.addEventListener("submit", (e) => {
    e.preventDefault();
    // Ici, vous intégreriez la logique de traitement de paiement par carte
    alert("Traitement du paiement par carte bancaire...");
  });
});
