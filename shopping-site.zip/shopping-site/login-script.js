document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("login-form");
  const signupForm = document.getElementById("signup-form");
  const switchToSignup = document.getElementById("switch-to-signup");
  const formTitle = document.getElementById("form-title");
  const switchForm = document.getElementById("switch-form");

  loginForm.addEventListener("submit", handleLogin);
  signupForm.addEventListener("submit", handleSignup);
  switchToSignup.addEventListener("click", toggleForms);

  function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById("login-email").value;
    const password = document.getElementById("login-password").value;

    const users = JSON.parse(localStorage.getItem("users")) || [];
    const user = users.find(
      (u) => u.email === email && u.password === password
    );

    if (user) {
      alert("Connexion réussie !");
      localStorage.setItem("currentUser", JSON.stringify(user));
      window.location.href = "mon-compte.html"; // Rediriger vers la page d'accueil
    } else {
      alert("Email ou mot de passe incorrect.");
    }
  }

  function handleSignup(e) {
    e.preventDefault();
    const name = document.getElementById("signup-name").value;
    const email = document.getElementById("signup-email").value;
    const password = document.getElementById("signup-password").value;

    const users = JSON.parse(localStorage.getItem("users")) || [];

    if (users.find((u) => u.email === email)) {
      alert("Cet email est déjà utilisé.");
      return;
    }

    const newUser = { name, email, password };
    users.push(newUser);
    localStorage.setItem("users", JSON.stringify(users));

    alert("Inscription réussie ! Vous pouvez maintenant vous connecter.");
    toggleForms();
  }

  function toggleForms() {
    loginForm.style.display =
      loginForm.style.display === "none" ? "flex" : "none";
    signupForm.style.display =
      signupForm.style.display === "none" ? "flex" : "none";
    formTitle.textContent =
      loginForm.style.display === "none" ? "Inscription" : "Connexion";
    switchForm.innerHTML =
      loginForm.style.display === "none"
        ? 'Déjà un compte ? <a href="#" id="switch-to-login">Se connecter</a>'
        : 'Pas de compte ? <a href="#" id="switch-to-signup">S\'inscrire</a>';

    document
      .getElementById(
        loginForm.style.display === "none"
          ? "switch-to-login"
          : "switch-to-signup"
      )
      .addEventListener("click", toggleForms);
  }
});
