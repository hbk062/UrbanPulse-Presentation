const trendingProducts = [
  {
    id: 1,
    name: "Sneakers Holographiques",
    price: 129.99,
    image: "https://example.com/sneakers-holo.jpg",
  },
  {
    id: 2,
    name: "T-shirt Connecté",
    price: 59.99,
    image: "https://example.com/tshirt-connecte.jpg",
  },
  {
    id: 3,
    name: "Sac à Dos Antigravité",
    price: 199.99,
    image: "https://example.com/sac-antigravite.jpg",
  },
  {
    id: 4,
    name: "Lunettes AR",
    price: 299.99,
    image: "https://example.com/lunettes-ar.jpg",
  },
  {
    id: 5,
    name: "Montre Quantique",
    price: 499.99,
    image: "https://example.com/montre-quantique.jpg",
  },
  {
    id: 6,
    name: "Veste Caméléon",
    price: 249.99,
    image: "https://example.com/veste-cameleon.jpg",
  },
];

function displayTrendingProducts() {
  const trendingGrid = document.getElementById("trendingGrid");
  trendingProducts.forEach((product) => {
    const productElement = document.createElement("div");
    productElement.classList.add("trending-item");
    productElement.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.price.toFixed(2)} $</p>
            <button onclick="addToCart(${
              product.id
            })">Ajouter au panier</button>
        `;
    trendingGrid.appendChild(productElement);
  });
}

document.addEventListener("DOMContentLoaded", displayTrendingProducts);

function addToCart(productId) {
  const product = trendingProducts.find((p) => p.id === productId);
  if (product) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    const existingItem = cart.find((item) => item.id === product.id);
    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      cart.push({ ...product, quantity: 1 });
    }
    localStorage.setItem("cart", JSON.stringify(cart));
    alert(`${product.name} a été ajouté au panier !`);
    updateCartDisplay(); // Si vous avez une fonction pour mettre à jour l'affichage du panier
  }
}

function updateCartDisplay() {
  const cartItems = JSON.parse(localStorage.getItem("cart")) || [];
  const cartElement = document.getElementById("cart-items");
  if (cartElement) {
    cartElement.innerHTML = cartItems
      .map(
        (item) => `
      <div>${item.name} - Quantité: ${item.quantity}</div>
    `
      )
      .join("");
  }
}

// Appelez cette fonction au chargement de la page
document.addEventListener("DOMContentLoaded", () => {
  displayTrendingProducts();
  updateCartDisplay();
});
