document.addEventListener("DOMContentLoaded", () => {
  const currentUser = JSON.parse(localStorage.getItem("currentUser"));
  if (!currentUser) {
    window.location.href = "login.html";
    return;
  }

  const personalInfoForm = document.getElementById("personal-info-form");
  const passwordForm = document.getElementById("password-form");
  const addressForm = document.getElementById("address-form");
  const logoutBtn = document.getElementById("logout-btn");

  // Remplir les champs avec les informations actuelles de l'utilisateur
  document.getElementById("name").value = currentUser.name || "";
  document.getElementById("email").value = currentUser.email || "";
  document.getElementById("phone").value = currentUser.phone || "";
  document.getElementById("street").value = currentUser.address?.street || "";
  document.getElementById("city").value = currentUser.address?.city || "";
  document.getElementById("postal-code").value =
    currentUser.address?.postalCode || "";
  document.getElementById("country").value = currentUser.address?.country || "";

  personalInfoForm.addEventListener("submit", (e) => {
    e.preventDefault();
    currentUser.name = document.getElementById("name").value;
    currentUser.email = document.getElementById("email").value;
    currentUser.phone = document.getElementById("phone").value;
    updateUser(currentUser);
    alert("Informations personnelles mises à jour !");
  });

  passwordForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const currentPassword = document.getElementById("current-password").value;
    const newPassword = document.getElementById("new-password").value;
    const confirmPassword = document.getElementById("confirm-password").value;

    if (currentPassword !== currentUser.password) {
      alert("Le mot de passe actuel est incorrect.");
      return;
    }

    if (newPassword !== confirmPassword) {
      alert("Les nouveaux mots de passe ne correspondent pas.");
      return;
    }

    currentUser.password = newPassword;
    updateUser(currentUser);
    alert("Mot de passe changé avec succès !");
    passwordForm.reset();
  });

  addressForm.addEventListener("submit", (e) => {
    e.preventDefault();
    currentUser.address = {
      street: document.getElementById("street").value,
      city: document.getElementById("city").value,
      postalCode: document.getElementById("postal-code").value,
      country: document.getElementById("country").value,
    };
    updateUser(currentUser);
    alert("Adresse de livraison mise à jour !");
  });

  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("currentUser");
    window.location.href = "index.html";
  });

  function updateUser(user) {
    localStorage.setItem("currentUser", JSON.stringify(user));
    const users = JSON.parse(localStorage.getItem("users")) || [];
    const index = users.findIndex((u) => u.email === user.email);
    if (index !== -1) {
      users[index] = user;
      localStorage.setItem("users", JSON.stringify(users));
    }
  }
});
