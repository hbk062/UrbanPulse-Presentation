<?php
session_start();
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Vérifiez si le nom d'utilisateur existe déjà (simulé ici)
    $users = file_get_contents('users.txt');
    if (strpos($users, $username) !== false) {
        $error = "Ce nom d'utilisateur existe déjà.";
    } else {
        // Enregistrez le nouvel utilisateur (simulé ici)
        file_put_contents('users.txt', $username . ":" . password_hash($password, PASSWORD_DEFAULT) . "\n", FILE_APPEND);
        $_SESSION['username'] = $username;
        header("Location: welcome.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription</title>
</head>
<body>
    <h2>Inscription</h2>
    <form method="post" action="">
        Nom d'utilisateur: <input type="text" name="username" required><br>
        Mot de passe: <input type="password" name="password" required><br>
        <input type="submit" value="S'inscrire">
    </form>
    <?php if($error) echo "<p style='color:red;'>$error</p>"; ?>
    <p>Déjà inscrit ? <a href="login.php">Connectez-vous ici</a></p>
</body>
</html>
