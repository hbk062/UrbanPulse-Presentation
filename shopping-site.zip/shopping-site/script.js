const produitsTendance = [
  {
    nom: "Hoodie Cyber",
    prix: 59.99,
    image: "hoodie-cyber.jpg",
    tags: ["Streetwear", "High-Tech"],
  },
  {
    nom: "Sneakers Holographiques",
    prix: 129.99,
    image: "sneakers-holo.jpg",
    tags: ["Luxe", "Technologie"],
  },
  // Ajouter plus de produits
];

function renderProduits() {
  const grid = document.querySelector(".product-grid");
  produitsTendance.forEach((produit) => {
    const card = document.createElement("div");
    card.classList.add("product-card");
    card.innerHTML = `
            <img src="${produit.image}" alt="${produit.nom}">
            <h3>${produit.nom}</h3>
            <p>${produit.prix}€</p>
            <div class="product-tags">
                ${produit.tags
                  .map((tag) => `<span class="tag">${tag}</span>`)
                  .join("")}
            </div>
            <button class="add-to-cart">Ajouter</button>
        `;
    grid.appendChild(card);
  });
}

document.addEventListener("DOMContentLoaded", renderProduits);

function addToCart(product) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  const existingItem = cart.find((item) => item.id === product.id);
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({ ...product, quantity: 1 });
  }
  localStorage.setItem("cart", JSON.stringify(cart));
  alert("Produit ajouté au panier !");
}
