const categories = [
  {
    id: 1,
    name: "Vêtements High-Tech",
    image: "https://example.com/vetements-tech.jpg",
  },
  {
    id: 2,
    name: "Accessoires Futuristes",
    image: "https://example.com/accessoires-futur.jpg",
  },
  {
    id: 3,
    name: "Chaussures Intelligentes",
    image: "https://example.com/chaussures-smart.jpg",
  },
  {
    id: 4,
    name: "Gadgets Portables",
    image: "https://example.com/gadgets-portables.jpg",
  },
  { id: 5, name: "Mode Écologique", image: "https://example.com/mode-eco.jpg" },
  {
    id: 6,
    name: "Cosmétiques Innovants",
    image: "https://example.com/cosmetiques-innovants.jpg",
  },
];

function displayCategories() {
  const categoryGrid = document.getElementById("categoryGrid");
  categories.forEach((category) => {
    const categoryElement = document.createElement("div");
    categoryElement.classList.add("category-item");
    categoryElement.innerHTML = `
            <img src="${category.image}" alt="${category.name}">
            <h3>${category.name}</h3>
        `;
    categoryElement.addEventListener("click", () => {
      // Rediriger vers la page de la catégorie
      console.log(`Naviguer vers la catégorie: ${category.name}`);
    });
    categoryGrid.appendChild(categoryElement);
  });
}

document.addEventListener("DOMContentLoaded", displayCategories);
